package guiSolitaire;


public enum CardColor {
	BLACK, RED
}