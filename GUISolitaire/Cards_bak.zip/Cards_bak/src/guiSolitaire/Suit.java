package guiSolitaire;


public enum Suit {
	HEART, DIAMOND, SPADE, CLUB
}